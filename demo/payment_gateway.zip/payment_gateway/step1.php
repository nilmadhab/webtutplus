<!DOCTYPE html>
<html>
<head>
	<title>Webtut plus Integrate paypal </title>

	 <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"
    rel="stylesheet">
</head>
<body>
	<div class="container">
	<h1 class="bg-info" style="text-align:center"> Paypal Payment Gateway Intergation </h1>
	</div>
	<div class="container" style="margin-top:50px">

        <div class="col-sm-4">
            <img src="P1.jpg" width="200"><br>
           	<p> $100 </p>
         
           
        </div>

        <div class="col-sm-4">
            <img src="P2.jpg" width="200"><br>
           
            <br>
            <p> $200 </p>
           
        </div>

        <div class="col-sm-4">
            <img src="P3.jpg" width="200"><br>
            <p> $300 </p>
          
          
    </div>
	


</body>
</html>

