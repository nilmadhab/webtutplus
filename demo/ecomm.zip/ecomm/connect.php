	<?php 

	$conn=mysqli_connect('localhost','webtutplus','webtutplus','webtut_ecomm')or die("cannot connect");
	if (!$conn) {
		echo "cannot connect";
	}


	?>