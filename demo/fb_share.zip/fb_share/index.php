<!DOCTYPE html>
<html>
<head>
	<title>Facebook Share</title>
	 <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"
    rel="stylesheet">
   
</head>
<body>
<div id="fb-root"></div>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4&appId=271577596358928";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>


	<div class="container">
		<h2 style="text-align:center">Facebook and Twitter Share  </h2>
		<div class="container" style="margin-top:200px">

			<div class="col-sm-6">
				<div class="fb-share-button" style="transform: scale(2.0);" data-href="http://webtutplus.com/" data-layout="button_count"></div>
			</div>
			<div class="col-sm-6">
				<a href="https://twitter.com/home?status=http://webtutplus.com/"  class="twitter-share-button" > </a>
				<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
			</div>


			
			
		</div>
		

			
	</div>


</body>
</html>

