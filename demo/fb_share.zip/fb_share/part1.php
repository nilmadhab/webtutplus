<!DOCTYPE html>
<html>
<head>
	<title>Facebook Share</title>
	 <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"
    rel="stylesheet">
   
</head>
<body>


	<div class="container">
		<h2 style="text-align:center">Facebook Like and share  </h2>
		<div class="container">
			
		</div>
			
	</div>

</body>
</html>