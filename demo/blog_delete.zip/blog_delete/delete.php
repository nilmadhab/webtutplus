<?php 

// make database connection
$conn=mysql_connect( 'localhost','root','')or die("cannot connect");
if (!$conn) {
	return false;
}
// select database
if (!mysql_select_db('blog',$conn)){
	return false;
}

$post_id = $_GET['post_id']; // store post_id in a varible

$sql = "DELETE FROM `posts` WHERE post_id = '$post_id'"; // sql command to delete

$result = mysql_query($sql,$conn); // execute the sql command

header("Location: index.php"); // go back to index page



?>