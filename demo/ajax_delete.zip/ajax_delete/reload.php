<?php 

// make database connection
$conn=mysql_connect( 'sql307.byethost16.com','b16_16292463','shubham123')or die("cannot connect");
if (!$conn) {
	return false;
}
// select database
if (!mysql_select_db('b16_16292463_blog',$conn)){
	return false;
}

 $sql = "SELECT * FROM Posts";
	      if($result = mysql_query($sql,$conn)){
			while($row = mysql_fetch_array($result)){
				echo "<tr>";
					echo "<td>{$row['post_id']}</td>";
					echo "<td>{$row['title']}</td>";
					echo "<td>{$row['post']}</td>";
					$post_id  = $row['post_id'];
					echo "<td onclick='delete_ajax($post_id)'><span class='btn btn-danger'>
								Delete</span></td>"; // pass post_id as parameter and add class to button
								// to make the button look nice.
				echo "</tr>";
			}
		}

?>