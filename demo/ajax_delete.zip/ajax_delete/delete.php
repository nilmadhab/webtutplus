<?php 

// make database connection
$conn=mysql_connect( 'sql307.byethost16.com','b16_16292463','shubham123')or die("cannot connect");
if (!$conn) {
	return false;
}
// select database
if (!mysql_select_db('b16_16292463_blog',$conn)){
	return false;
}

$post_id = $_GET['id']; // store post_id in a varible

$sql = "DELETE FROM `Posts` WHERE post_id = '$post_id'"; // sql command to delete

$result = mysql_query($sql,$conn); // execute the sql command



?>