	<?php 

	$conn=mysqli_connect( 'sql110.byethost7.com','b7_16441468','wjd657x9',' b7_16441468_ecomm')or die("cannot connect why ?");
	if (!$conn) {
		echo "cannot connect";
	}
   // pass wjd657x9

	?>	