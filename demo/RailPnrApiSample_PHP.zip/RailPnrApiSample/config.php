<?php
define("PUBLIC_KEY", "229ca76e6995d7fdc3320843bf282399"); //Put your public key here.
define("PRIVATE_KEY", "ce3e2ace4dcc3041fdfd2a73ab23256b"); //Put your private key here.
define("FORMAT", "json"); //Response format.
