<!DOCTYPE html>
<html>
<head>
    <title>pin interest sharing</title>
    <!-- Latest compiled and minified CSS -->
    <link href=
    "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"
    rel="stylesheet">
</head>

<body>
    <div class="container" style="margin-top:50px">
        <div class="col-sm-4">
            <img src="P1.jpg" width="200"><br>
            <a data-pin-color="red" data-pin-do="buttonPin" data-pin-height=
            "28" href=
            "//www.pinterest.com/pin/create/button/?url=http%3A%2F%2Fliberent.byethost7.com%2Fliberent%2Fpin.php&media=http%3A%2F%2Fliberent.byethost7.com%2Fliberent%2FP1.jpg&description=Next%20stop%3A%20Pinterest">
            <img src=
            "//assets.pinterest.com/images/pidgets/pinit_fg_en_rect_red_28.png"></a>
        </div>

        <div class="col-sm-4">
            <img src="P2.jpg" width="200"><br>
            <a data-pin-color="red" data-pin-do="buttonPin" data-pin-height=
            "28" href=
            "//www.pinterest.com/pin/create/button/?url=http%3A%2F%2Fliberent.byethost7.com%2Fliberent%2Fpin.php&media=http%3A%2F%2Fliberent.byethost7.com%2Fliberent%2FP2.jpg&description=Next%20stop%3A%20Pinterest">
            <img src=
            "//assets.pinterest.com/images/pidgets/pinit_fg_en_rect_red_28.png"></a><br>
            <br>
        </div>

        <div class="col-sm-4">
            <img src="P3.jpg" width="200"><br>
            <a data-pin-color="red" data-pin-do="buttonPin" data-pin-height=
            "28" href=
            "//www.pinterest.com/pin/create/button/?url=http%3A%2F%2Fliberent.byethost7.com%2Fliberent%2Fpin.php&media=http%3A%2F%2Fliberent.byethost7.com%2Fliberent%2FP3.jpg&description=Next%20stop%3A%20Pinterest">
            <img src=
            "//assets.pinterest.com/images/pidgets/pinit_fg_en_rect_red_28.png"></a><br>
            <br>
        </div><!-- Please call pinit.js only once per page -->
        <script async="" defer src="//assets.pinterest.com/js/pinit.js" type=
        "text/javascript"></script> 
    </div>
</body>
</html>